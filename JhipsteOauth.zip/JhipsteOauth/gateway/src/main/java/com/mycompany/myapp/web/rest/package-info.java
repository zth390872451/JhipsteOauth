/**
 * Spring MVC REST controllers.
 */
package com.mycompany.myapp.web.rest;
