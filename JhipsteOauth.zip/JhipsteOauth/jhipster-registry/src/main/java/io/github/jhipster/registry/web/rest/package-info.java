/**
 * Spring MVC REST controllers.
 */
package io.github.jhipster.registry.web.rest;
